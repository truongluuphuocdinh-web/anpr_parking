import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import Database
from plate_utils import levenshtein, normalize, is_valid, pretty
from services import ParkingService, FeeService

RULE = dict(free_minutes=15, block_minutes=60, block_price=5000, daily_cap=30000, lost_ticket_fee=50000)


class Clock:
    def __init__(self):
        self.t = datetime(2026, 11, 19, 8, 0, 0)

    def __call__(self):
        return self.t


@pytest.fixture
def env(tmp_path):
    clock = Clock()
    db = Database(tmp_path / "t.db")
    return ParkingService(db, clock=clock, rng=random.Random(1)), clock, db


def scan(svc, plate):
    k = normalize(plate)
    return svc.process_scan(pretty(k), k)


# ---------- tiện ích biển ----------
def test_normalize_and_format():
    assert normalize("59d1-123.45") == "59D112345"
    assert normalize("S9D1-123.4S") == "59D112345"      # sửa nhầm S->5 ở vị trí số
    assert is_valid("59D112345") and is_valid("51F12345") and is_valid("29MD12345")
    assert not is_valid("ABC") and not is_valid("")
    assert pretty("59D112345") == "59D1-123.45" and pretty("51F12345") == "51F-123.45"


def test_levenshtein():
    assert levenshtein("59D112345", "59O112345") == 1
    assert levenshtein("abc", "abc") == 0 and levenshtein("", "abc") == 3


# ---------- tính phí ----------
@pytest.mark.parametrize("minutes,fee", [(10, 0), (15, 0), (16, 5000), (61, 10000), (300, 25000),
                                         (600, 30000), (1500, 60000)])
def test_fee(minutes, fee):
    assert FeeService.calculate(minutes, RULE) == fee


# ---------- luồng nghiệp vụ ----------
def test_checkin_then_checkout(env):
    svc, clock, db = env
    o = scan(svc, "59D1-123.45")
    assert o.action == "CHECK_IN" and o.slot and db.total_in_lot() == 1
    clock.t += timedelta(minutes=90)
    o = scan(svc, "59D1-123.45")
    assert o.action == "CHECK_OUT" and o.fee == 10000 and o.fee_type == "REGULAR"
    assert db.total_in_lot() == 0 and len(db.free_slots()) == 9


def test_near_match_yellow_warning(env):
    svc, clock, db = env
    scan(svc, "59D1-123.45")
    o = svc.process_scan("59O1-123.45", "59O112345")          # đọc nhầm D -> O
    assert o.action == "WARN_NEAR" and o.distance == 1
    assert db.total_in_lot() == 1                               # chưa đổi trạng thái
    clock.t += timedelta(minutes=30)
    o2 = svc.confirm_near_checkout(o.near_log["id"])
    assert o2.action == "CHECK_OUT" and o2.plate == "59D1-123.45" and db.total_in_lot() == 0


def test_near_but_different_car_can_check_in(env):
    svc, _, db = env
    scan(svc, "59D1-123.45")
    o = svc.process_scan("59O1-123.45", "59O112345")
    o = svc.check_in("59O1-123.45", "59O112345")               # bảo vệ chọn "xe khác"
    assert o.action == "CHECK_IN" and db.total_in_lot() == 2


def test_subscription_free_and_expired(env):
    svc, clock, db = env
    day = clock.t.date()
    db.add_subscription("51F12345", "51F-123.45", "An", (day - timedelta(days=5)).isoformat(),
                        (day + timedelta(days=5)).isoformat(), 1)
    scan(svc, "51F-123.45")
    clock.t += timedelta(hours=3)
    o = scan(svc, "51F-123.45")
    assert o.fee == 0 and o.fee_type == "SUBSCRIPTION"
    # vé đã hết hạn -> thu vé lẻ
    db.add_subscription("52G12345", "52G-123.45", "Bình", "2026-01-01", "2026-02-01", 1)
    scan(svc, "52G-123.45")
    clock.t += timedelta(hours=2)
    o = scan(svc, "52G-123.45")
    assert o.fee_type == "EXPIRED_SUB" and o.fee == 10000
    with pytest.raises(ValueError):                              # trùng vé còn hạn
        db.add_subscription("51F12345", "51F-123.45", "An", day.isoformat(), day.isoformat(), 1)


def test_lot_full(env):
    svc, _, db = env
    plates = ["11A-111.11", "22B-222.22", "33C-333.33", "44D-444.44", "55E-555.55",
              "66F-666.66", "77G-777.77", "88H-888.88", "99K-999.99"]
    for p in plates:
        assert scan(svc, p).action == "CHECK_IN"
    o = scan(svc, "12L-345.67")
    assert o.action == "LOT_FULL" and db.total_in_lot() == 9


def test_find_move_and_top5(env):
    svc, _, db = env
    o = scan(svc, "59D1-123.45")
    assert svc.find_car("59D112345").log["slot_code"] == o.slot
    dst = next(s["code"] for s in db.free_slots() if s["code"] != o.slot)
    svc.move_car(o.slot, dst)
    assert svc.find_car("59D112345").log["slot_code"] == dst
    with pytest.raises(ValueError):
        svc.move_car(o.slot, dst)                                # ô nguồn giờ trống
    for p in ("59D1-123.46", "59D1-999.99", "30A-111.11"):
        k = normalize(p)
        svc.check_in(pretty(k), k)                               # bỏ qua cảnh báo vàng, cho vào trực tiếp
    top = svc.top_similar("59D112347", 5)
    assert len(top) == 4 and top[0][0] <= top[-1][0]


def test_lost_ticket_and_reports(env, tmp_path):
    svc, clock, db = env
    scan(svc, "59D1-123.45")
    log = db.open_logs()[0]
    clock.t += timedelta(hours=1)
    o = svc.checkout_lost(log["id"])
    assert o.fee == 50000 and o.fee_type == "LOST_TICKET"
    stats = db.daily_stats("2026-11-01", "2026-11-30")
    assert stats == [dict(day="2026-11-19", vao=1, ra=1, doanh_thu=50000)]
    assert len(db.history_page(None, 50)) == 1
    out = svc.export_excel("2026-11-01", "2026-11-30", tmp_path / "r.xlsx")
    assert Path(out).exists()


def test_login(env):
    svc, _, _ = env
    assert svc.login("admin", "admin123")["role"] == "ADMIN"
    assert svc.login("baove", "sai") is None
