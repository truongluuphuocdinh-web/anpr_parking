"""Audit log, hiệu năng, mất thẻ, chấm điểm và web Admin (chạy thật máy chủ HTTP trên cổng ngẫu nhiên)."""
import http.cookiejar
import random
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import admin_web
import evaluate
from db import Database
from plate_utils import normalize, pretty
from services import AUDIT_SENSITIVE, ParkingService


def mk(tmp):
    db = Database(Path(tmp) / "t.db")
    return ParkingService(db, clock=lambda: datetime(2026, 11, 22, 8, 0, 0), rng=random.Random(1)), db


def test_audit_is_append_only(tmp_path):
    svc, db = mk(tmp_path)
    svc.log_event("MANUAL_ENTRY", "59D112345", "x", 1)
    for sql in ("DELETE FROM event_log", "UPDATE event_log SET detail='sửa lén'", "UPDATE event_log SET user_id=2"):
        try:
            db.conn.execute(sql)
            assert False, "audit log bị sửa/xóa được: " + sql
        except Exception as e:
            assert "Audit" in str(e) or "audit" in str(e)
    assert db._all("SELECT detail FROM event_log")[0]["detail"] == "x"


def test_manual_edits_are_audited_with_user_and_before_after(tmp_path):
    svc, db = mk(tmp_path)
    svc.audit_manual(2, "59D1-123.48", 0.62, "59D1-123.45", "máy chưa chắc")
    svc.audit_manual(2, "", 0, "30A-123.45", "bảo vệ bấm nút Nhập tay")
    k = normalize("59D1-123.45")
    o = svc.check_in(pretty(k), k)
    svc.correct_plate(o.log_id, "59D1-123.46", normalize("59D1-123.46"), 2)
    rows = db.audit_page(types=AUDIT_SENSITIVE)
    assert {r["event_type"] for r in rows} >= {"OCR_CORRECTED", "MANUAL_ENTRY", "PLATE_CORRECTED"}
    first = next(r for r in rows if r["event_type"] == "OCR_CORRECTED")
    assert first["username"] == "baove" and "59D1-123.48" in first["detail"] and "59D1-123.45" in first["detail"]


def test_near_confirm_lost_subscription_and_login_fail_audited(tmp_path):
    svc, db = mk(tmp_path)
    k = normalize("59D1-123.45")
    o = svc.check_in(pretty(k), k)
    svc.confirm_near_checkout(o.log_id, None, "MANUAL", 2, "59O1-123.45")
    k2 = normalize("30A-123.45")
    o2 = svc.check_in(pretty(k2), k2)
    svc.checkout_lost(o2.log_id, None, 2, "30A-999.99")
    svc.add_subscription(k, pretty(k), "An", "2026-11-01", "2026-12-01", 1)
    svc.renew_subscription(k, 1)
    sid = db._one("SELECT id FROM subscription")["id"]
    svc.delete_subscription(sid, 1)
    assert svc.login("baove", "sai") is None
    types = {r["event_type"] for r in db.audit_page(size=100)}
    assert {"NEAR_CONFIRMED", "LOST_TICKET", "SUB_ADDED", "SUB_RENEWED", "SUB_DELETED", "LOGIN_FAIL"} <= types


def test_perf_summary_and_target(tmp_path):
    svc, db = mk(tmp_path)
    assert db.perf_summary() is None
    for ms in (300, 500, 700, 900, 2000):
        svc.record_perf("GATE", ms)
    p = db.perf_summary()
    assert p["n"] == 5 and p["p50"] == 700 and p["ok_pct"] == 80.0 and p["max"] == 2000


def test_lost_candidates_top_n_vs_all(tmp_path):
    svc, db = mk(tmp_path)
    for p in ("59D1-111.11", "59D1-222.22", "30A-333.33", "51F-444.44", "29B1-555.55", "60A-666.66", "61A-777.77"):
        k = normalize(p)
        svc.check_in(pretty(k), k)
    q = normalize("59D1-111.12")
    assert len(svc.lost_candidates(q)) == 5 and len(svc.lost_candidates(q, True)) == 7
    assert svc.lost_candidates(q)[0][1]["plate_text"] == "59D1-111.11"


def test_evaluate_metrics():
    items = [("a", "59D112345"), ("b", "30A12345"), ("c", "51F67890")]
    guess = {"a": "59D112345", "b": "30A12845", "c": ""}
    r = evaluate.evaluate(items, lambda p: guess[p])
    assert abs(r["plate_acc"] - 1 / 3) < 1e-9
    assert abs(r["char_acc"] - (1 - (0 + 1 + 8) / (9 + 8 + 8))) < 1e-9        # 9 lỗi / 25 ký tự đúng
    assert r["n"] == 3 and r["avg_ms"] >= 0


def test_evaluate_labels_from_filename(tmp_path):
    for n in ("59D1-123.45.jpg", "30A12345__ban_ngay.png", "linhtinh.jpg"):
        (Path(tmp_path) / n).write_bytes(b"x")
    got = {k for _, k in evaluate.load_labels(Path(tmp_path))}
    assert got == {"59D112345", "30A12345"}


# ---------------- web Admin ----------------
class Web:
    def __init__(self, tmp):
        self.db_path = Path(tmp) / "w.db"
        Database(self.db_path)
        self.srv, self.url = admin_web.start("127.0.0.1", 0, self.db_path)
        self.base = f"http://127.0.0.1:{self.srv.server_address[1]}"
        self.jar = http.cookiejar.CookieJar()
        self.op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def req(self, path, data=None, follow=True):
        body = urllib.parse.urlencode(data).encode() if data is not None else None
        try:
            if not follow:
                class NoRedir(urllib.request.HTTPRedirectHandler):
                    def redirect_request(self, *a, **k):
                        return None
                op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar), NoRedir)
            else:
                op = self.op
            r = op.open(self.base + path, body, timeout=10)
            return r.status, r.read(), r.headers
        except urllib.error.HTTPError as e:
            return e.code, e.read(), e.headers

    def login(self, u="admin", p="admin123"):
        return self.req("/login", {"username": u, "password": p})

    def csrf(self, page="/subs"):
        return re.search(rb'name="csrf" value="([^"]+)"', self.req(page)[1]).group(1).decode()

    def close(self):
        self.srv.shutdown()


def test_web_requires_login_and_admin_role(tmp_path):
    w = Web(tmp_path)
    try:
        st, _, h = w.req("/", follow=False)
        assert st == 303 and h["Location"] == "/login"
        assert w.req("/audit", follow=False)[0] == 303
        assert w.login("baove", "baove123")[0] == 401                  # bảo vệ không vào được web Admin
        assert w.login("admin", "sai")[0] == 401
        st, body, h = w.login()
        assert st == 200 and "Tổng quan" in body.decode() and "mật khẩu mặc định" in body.decode()
        assert "X-Frame-Options" in h and "default-src" in h["Content-Security-Policy"]
    finally:
        w.close()


def test_web_subscription_crud_csrf_xss_and_audit(tmp_path):
    w = Web(tmp_path)
    try:
        w.login()
        tok = w.csrf()
        bad = w.req("/subs/add", {"csrf": "sai", "plate": "59D1-123.45", "owner": "A", "start": "2026-11-01",
                                  "end": "2026-12-01"})
        assert bad[0] == 403                                            # không có CSRF đúng -> từ chối
        w.req("/subs/add", {"csrf": tok, "plate": "59D1-123.45", "owner": "<script>alert(1)</script>",
                            "start": "2026-11-01", "end": "2026-12-01"})
        page = w.req("/subs")[1].decode()
        assert "59D1-123.45" in page and "<script>alert(1)</script>" not in page and "&lt;script&gt;" in page
        err = w.req("/subs/add", {"csrf": tok, "plate": "SAI", "owner": "", "start": "2026-11-01", "end": "2026-12-01"})
        assert "không hợp lệ" in err[1].decode()
        db = Database(w.db_path)
        sid = db._one("SELECT id FROM subscription")["id"]
        w.req("/subs/renew", {"csrf": tok, "id": sid})
        assert len(db.list_subscriptions()) == 2
        w.req("/subs/delete", {"csrf": tok, "id": sid})
        types = [r["event_type"] for r in db.audit_page(size=50)]
        assert "SUB_ADDED" in types and "SUB_RENEWED" in types and "SUB_DELETED" in types
        audit = w.req("/audit")[1].decode()
        assert "Thêm vé tháng" in audit and "admin" in audit
    finally:
        w.close()


def test_web_export_history_password_and_logout(tmp_path):
    w = Web(tmp_path)
    try:
        w.login()
        st, body, h = w.req("/export?from=2026-11-01&to=2026-11-30")
        assert st == 200 and body[:2] == b"PK" and "spreadsheetml" in h["Content-Type"]
        assert w.req("/export_audit?t=all")[1][:2] == b"PK"
        assert "Lịch sử" in w.req("/history?q=59D1")[1].decode()
        tok = w.csrf("/password")
        w.req("/password", {"csrf": tok, "old": "admin123", "new": "MatKhauMoi1", "new2": "MatKhauMoi1"})
        assert Database(w.db_path).verify_user("admin", "MatKhauMoi1")
        assert "mật khẩu mặc định" not in w.req("/")[1].decode()
        w.req("/logout", {"csrf": tok})
        assert w.req("/", follow=False)[0] == 303
    finally:
        w.close()


def test_web_login_lockout_after_5_failures(tmp_path):
    w = Web(tmp_path)
    try:
        for _ in range(5):
            w.login("admin", "sai")
        assert "quá nhiều" in w.login("admin", "admin123")[1].decode()  # đúng mật khẩu cũng bị khóa tạm
    finally:
        w.close()
