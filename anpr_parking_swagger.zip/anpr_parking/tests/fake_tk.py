"""Tkinter GIẢ (không cần màn hình) để chạy thử code giao diện trong môi trường không có Tk.

Không vẽ gì cả, nhưng kiểm tra NGHIÊM các lỗi hay gặp làm app chết lúc khởi động:
  - tùy chọn widget không tồn tại (vd dùng bg/fg cho widget ttk -> TclError thật)
  - tùy chọn pack/grid/place sai, gọi phương thức không có
Dùng:  import fake_tk; fake_tk.install()  TRƯỚC khi import app.
"""
import sys
import types
from itertools import count

_ids = count(1)


class TclError(Exception):
    pass


def _opts(*groups):
    out = set()
    for g in groups:
        out |= set(g.split())
    return out


COMMON_TK = "bg background bd borderwidth relief highlightthickness highlightbackground highlightcolor cursor takefocus"
LABEL_TK = _opts(COMMON_TK, "text textvariable image bitmap compound anchor justify wraplength width height font fg "
                 "foreground padx pady state underline activebackground activeforeground disabledforeground")
BUTTON_TK = LABEL_TK | {"command", "default", "overrelief", "repeatdelay", "repeatinterval"}
FRAME_TK = _opts(COMMON_TK, "width height padx pady class_ container colormap visual")
LISTBOX_TK = _opts(COMMON_TK, "height width font activestyle selectbackground selectforeground selectmode "
                   "exportselection fg foreground yscrollcommand xscrollcommand listvariable state "
                   "disabledforeground setgrid selectborderwidth")
TTK_BASE = "style cursor takefocus class_"
TTK = {
    "Frame": _opts(TTK_BASE, "padding relief borderwidth width height"),
    "Label": _opts(TTK_BASE, "text textvariable image compound anchor justify wraplength width font foreground "
                   "background relief padding underline state borderwidth"),
    "Button": _opts(TTK_BASE, "text textvariable command width padding image compound state default underline"),
    "Checkbutton": _opts(TTK_BASE, "text textvariable variable onvalue offvalue command width padding image compound "
                         "state underline"),
    "Entry": _opts(TTK_BASE, "textvariable show width font justify state validate validatecommand invalidcommand "
                   "exportselection xscrollcommand foreground background"),
    "Combobox": _opts(TTK_BASE, "textvariable show width font justify state validate validatecommand "
                      "invalidcommand exportselection xscrollcommand foreground background values height postcommand"),
    "Treeview": _opts(TTK_BASE, "columns displaycolumns show selectmode height padding yscrollcommand xscrollcommand"),
    "Notebook": _opts(TTK_BASE, "padding width height"),
    "LabelFrame": _opts(TTK_BASE, "text labelanchor labelwidget padding relief borderwidth width height underline"),
    "Scrollbar": _opts(TTK_BASE, "command orient"),
}
PACK = _opts("side fill expand padx pady ipadx ipady anchor before after in_")
GRID = _opts("row column rowspan columnspan sticky padx pady ipadx ipady in_")
PLACE = _opts("relx rely x y anchor relwidth relheight width height in_ bordermode")

METHODS = _opts(
    "pack grid place pack_forget grid_forget place_forget pack_propagate grid_propagate grid_columnconfigure "
    "grid_rowconfigure columnconfigure rowconfigure configure config cget keys bind bind_all unbind after "
    "after_cancel after_idle destroy winfo_children winfo_exists winfo_toplevel winfo_width winfo_height "
    "winfo_reqwidth winfo_reqheight winfo_rootx winfo_rooty winfo_screenwidth winfo_screenheight focus focus_set "
    "focus_force update update_idletasks bell lift lower title geometry minsize maxsize resizable protocol "
    "transient grab_set grab_release wait_window mainloop quit option_add attributes iconbitmap state "
    "clipboard_clear clipboard_append event_generate")
WIDGET_METHODS = {
    "Listbox": _opts("insert delete size get curselection itemconfig itemconfigure selection_set selection_clear "
                     "see yview xview activate nearest"),
    "Entry": _opts("get insert delete icursor selection_range set current selection_clear"),
    "Combobox": _opts("get insert delete icursor selection_range set current selection_clear"),
    "Treeview": _opts("insert delete get_children selection selection_set selection_remove item heading column "
                      "tag_configure focus see yview set index parent exists identify_row identify_region"),
    "Notebook": _opts("add tabs select forget tab index insert hide"),
}


class W:
    OPTS = set()
    KIND = ""

    def __init__(self, master=None, **kw):
        self.master = master
        self.children, self.opts, self.destroyed = [], {}, False
        self._bind, self._after, self._sel, self._items, self._text = {}, [], [], {}, []
        self._check(kw)
        self.opts.update(kw)
        if master is not None and hasattr(master, "children"):
            master.children.append(self)
        self.id = next(_ids)

    def _check(self, kw):
        for k in kw:
            if k not in self.OPTS:
                raise TclError(f'unknown option "-{k}" for {self.__class__.__module__.split(".")[-1]}.'
                               f'{self.__class__.__name__}')

    def __getattr__(self, name):
        if name in METHODS or name in WIDGET_METHODS.get(self.KIND, ()):
            return lambda *a, **k: None
        raise AttributeError(f"{self.__class__.__name__} không có phương thức '{name}' (typo?)")

    # --- bố cục ---
    def pack(self, **kw):
        bad = set(kw) - PACK
        if bad:
            raise TclError(f"bad pack option {bad}")
        return None

    def grid(self, **kw):
        bad = set(kw) - GRID
        if bad:
            raise TclError(f"bad grid option {bad}")

    def place(self, **kw):
        bad = set(kw) - PLACE
        if bad:
            raise TclError(f"bad place option {bad}")

    # --- cấu hình ---
    def configure(self, **kw):
        self._check(kw)
        self.opts.update(kw)

    config = configure

    def cget(self, k):
        return self.opts.get(k)

    def __setitem__(self, k, v):
        self.configure(**{k: v})

    def __getitem__(self, k):
        return self.opts.get(k)

    def bind(self, seq, fn=None, add=None):
        self._bind[seq] = fn

    def root(self):
        w = self
        while w.master is not None:
            w = w.master
        return w

    def after(self, ms, fn=None, *args):
        self.root()._pending.append((fn, args))
        return len(self.root()._pending)

    def winfo_children(self):
        return list(self.children)

    def winfo_exists(self):
        return 0 if self.destroyed else 1

    def winfo_toplevel(self):
        return self.root()

    def winfo_screenwidth(self):
        return 1920

    def winfo_screenheight(self):
        return 1080

    def destroy(self):
        for c in list(self.children):
            c.destroy()
        self.destroyed = True
        if self.master is not None and self in getattr(self.master, "children", []):
            self.master.children.remove(self)

    # --- Listbox ---
    def insert(self, a, b=None, *rest, **kw):
        if self.KIND == "Listbox":
            self._text.insert(0 if a == 0 else len(self._text), b)
            return
        if self.KIND in ("Entry", "Combobox"):
            return
        raise AttributeError("insert")

    def size(self):
        return len(self._text)

    def itemconfig(self, i, **kw):
        if self.KIND != "Listbox":
            raise AttributeError("itemconfig")
        if not self._text or i >= len(self._text):
            raise TclError("bad listbox index")

    itemconfigure = itemconfig


class Tk(W):
    OPTS = set()
    KIND = "Tk"

    def __init__(self):
        super().__init__(None)
        self._pending = []
        self.winfo_children_called = 0

    def run_pending(self, rounds=1):
        """Chạy các hàm after() đang chờ (mỗi vòng chạy một lượt)."""
        for _ in range(rounds):
            todo, self._pending = self._pending, []
            for fn, args in todo:
                if fn:
                    fn(*args)

    def title(self, *a):
        pass

    def configure(self, **kw):
        self.opts.update(kw)

    config = configure


class Toplevel(W):
    OPTS = FRAME_TK | {"menu", "screen"}
    KIND = "Toplevel"


class Frame(W):
    OPTS = FRAME_TK
    KIND = "Frame"


class Label(W):
    OPTS = LABEL_TK
    KIND = "Label"


class Button(W):
    OPTS = BUTTON_TK
    KIND = "Button"


class Listbox(W):
    OPTS = LISTBOX_TK
    KIND = "Listbox"


_TTK_CLASSES = {}


def _ttk(name):
    """Mỗi tên widget ttk chỉ có MỘT lớp (để so sánh isinstance ổn định qua nhiều lần install)."""
    if name not in _TTK_CLASSES:
        class C(W):
            OPTS = TTK[name]
            KIND = name

        C.__name__ = name
        _TTK_CLASSES[name] = C
    return _TTK_CLASSES[name]


class _EntryBase(_ttk("Entry")):
    def get(self):
        v = self.opts.get("textvariable")
        return v.get() if v else ""


class _ComboBase(_ttk("Combobox")):
    pass


class _TreeBase(_ttk("Treeview")):
    def insert(self, parent, index, iid=None, values=(), tags=(), **kw):
        iid = iid or f"I{next(_ids)}"
        self._items[iid] = {"values": list(values), "tags": tags}
        return iid

    def delete(self, *iids):
        for i in iids:
            self._items.pop(i, None)
        self._sel = [s for s in self._sel if s in self._items]

    def get_children(self, item=""):
        return tuple(self._items)

    def selection(self):
        return tuple(self._sel)

    def selection_set(self, *items):
        self._sel = list(items[0] if len(items) == 1 and isinstance(items[0], (list, tuple)) else items)
        fn = self._bind.get("<<TreeviewSelect>>")
        if fn:
            fn(None)

    def item(self, iid, option=None, **kw):
        return self._items[iid]

    def heading(self, *a, **k):
        pass

    def column(self, *a, **k):
        pass

    def tag_configure(self, *a, **k):
        pass


Entry, Combobox, Treeview = _EntryBase, _ComboBase, _TreeBase


class Var:
    def __init__(self, master=None, value=None, name=None):
        self.v = value

    def get(self):
        return self.v

    def set(self, v):
        self.v = v

    def trace_add(self, *a):
        pass


class StringVar(Var):
    def __init__(self, master=None, value="", name=None):
        super().__init__(master, value)


class BooleanVar(Var):
    def __init__(self, master=None, value=False, name=None):
        super().__init__(master, bool(value))

    def get(self):
        return bool(self.v)


class IntVar(Var):
    def __init__(self, master=None, value=0, name=None):
        super().__init__(master, value)


class Style:
    def __init__(self, master=None):
        self.cfg = {}

    def theme_use(self, name=None):
        return name

    def configure(self, name, **kw):
        self.cfg.setdefault(name, {}).update(kw)

    def map(self, name, **kw):
        pass

    def lookup(self, *a, **k):
        return ""


class Dialogs:
    """Hộp thoại giả: ghi lại các lần gọi, trả về giá trị do test cấu hình."""
    def __init__(self):
        self.calls, self.ask_string_result, self.yes = [], None, True
        self.save_path = ""

    def __getattr__(self, name):
        if name.startswith("show"):
            return lambda *a, **k: self.calls.append((name, a)) or "ok"
        raise AttributeError(name)

    def askyesno(self, *a, **k):
        self.calls.append(("askyesno", a))
        return self.yes

    askokcancel = askyesno

    def askstring(self, *a, **k):
        self.calls.append(("askstring", a))
        r = self.ask_string_result
        return r.pop(0) if isinstance(r, list) else r

    def asksaveasfilename(self, *a, **k):
        return self.save_path


DIALOGS = Dialogs()


def install():
    """Đăng ký tkinter giả vào sys.modules (gọi trước khi import app)."""
    ttk = types.ModuleType("tkinter.ttk")
    for name in ("Frame", "Label", "Button", "Checkbutton", "LabelFrame", "Notebook", "Scrollbar"):
        setattr(ttk, name, _ttk(name))
    ttk.Entry, ttk.Combobox, ttk.Treeview, ttk.Style = Entry, Combobox, Treeview, Style
    tk = types.ModuleType("tkinter")
    for name in ("Tk", "Toplevel", "Frame", "Label", "Button", "Listbox", "StringVar", "BooleanVar", "IntVar",
                 "TclError"):
        setattr(tk, name, globals()[name])
    tk.END, tk.ttk = "end", ttk
    tk.messagebox = tk.simpledialog = tk.filedialog = DIALOGS
    tk.Entry = Entry
    sys.modules.update({"tkinter": tk, "tkinter.ttk": ttk, "tkinter.messagebox": DIALOGS,
                        "tkinter.simpledialog": DIALOGS, "tkinter.filedialog": DIALOGS})
    imagetk = types.ModuleType("PIL.ImageTk")

    class PhotoImage:
        def __init__(self, img=None, **k):
            self.img = img

    imagetk.PhotoImage = PhotoImage
    sys.modules["PIL.ImageTk"] = imagetk
    import PIL
    PIL.ImageTk = imagetk
    return DIALOGS


def find(widget, cls=None, **match):
    """Tìm widget con (đệ quy) theo lớp + giá trị tùy chọn, vd find(root, Button, text='ĐĂNG NHẬP')."""
    out = []
    for c in widget.winfo_children():
        if (cls is None or isinstance(c, cls)) and all(c.opts.get(k) == v for k, v in match.items()):
            out.append(c)
        out += find(c, cls, **match)
    return out
