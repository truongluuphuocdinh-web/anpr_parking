"""Sửa biển đọc sai & hủy lượt vào nhập nhầm."""
import random
import sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import Database
from plate_utils import normalize, pretty
from services import ParkingService


class Clock:
    def __init__(self):
        self.t = datetime(2026, 11, 22, 8, 0, 0)

    def __call__(self):
        return self.t


def make(tmp):
    clock = Clock()
    db = Database(Path(tmp) / "t.db")
    return ParkingService(db, clock=clock, rng=random.Random(1)), clock, db


def checkin(svc, plate):
    k = normalize(plate)
    return svc.check_in(pretty(k), k)


def test_correct_plate_updates_and_logs(tmp_path):
    svc, _, db = make(tmp_path)
    o = checkin(svc, "59D1-123.48")                      # máy đọc sai số cuối
    k = normalize("59D1-123.45")
    svc.correct_plate(o.log_id, pretty(k), k, 1)
    assert db.get_log(o.log_id)["plate_key"] == k
    assert any(e for e in db._all("SELECT * FROM event_log WHERE event_type='PLATE_CORRECTED'"))
    assert svc.match_open(k).level == "EXACT"            # giờ quét lại đúng biển sẽ cho ra được


def test_correct_plate_rejects_duplicate_and_same(tmp_path):
    svc, _, db = make(tmp_path)
    a, b = checkin(svc, "59D1-123.45"), checkin(svc, "30A-123.45")
    for bad in ("30A12345", "59D112345"):
        try:
            svc.correct_plate(a.log_id, pretty(bad), bad, 1)
            assert False, "phải báo lỗi"
        except ValueError:
            pass


def test_void_frees_slot_and_audits(tmp_path):
    svc, clock, db = make(tmp_path)
    o = checkin(svc, "59D1-123.48")
    assert db.total_in_lot() == 1
    svc.void_checkin(o.log_id, 2, "GUARD")
    assert db.total_in_lot() == 0 and db.get_log(o.log_id) is None
    assert all(s["is_occupied"] == 0 for s in db._all("SELECT * FROM parking_slot"))
    ev = db._all("SELECT * FROM event_log WHERE event_type='CHECKIN_VOIDED'")
    assert len(ev) == 1 and "59D1-123.48" in ev[0]["plate_text"]
    checkin(svc, "59D1-123.45")                           # nhập lại đúng được ngay (không bị trùng chỉ mục)


def test_guard_void_only_in_window_admin_anytime(tmp_path):
    svc, clock, db = make(tmp_path)
    o = checkin(svc, "59D1-123.45")
    clock.t += timedelta(minutes=30)
    try:
        svc.void_checkin(o.log_id, 2, "GUARD")
        assert False, "bảo vệ không được hủy sau cửa sổ thời gian"
    except PermissionError:
        pass
    assert db.total_in_lot() == 1
    svc.void_checkin(o.log_id, 1, "ADMIN")
    assert db.total_in_lot() == 0


def test_void_already_out_rejected(tmp_path):
    svc, clock, db = make(tmp_path)
    o = checkin(svc, "59D1-123.45")
    svc.check_out(db.get_log(o.log_id))
    try:
        svc.void_checkin(o.log_id, 1, "ADMIN")
        assert False
    except ValueError:
        pass
