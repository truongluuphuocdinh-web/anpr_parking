"""Chạy thử TOÀN BỘ code giao diện bằng Tkinter giả (fake_tk): bắt lỗi tùy chọn widget, lỗi logic các luồng chính."""
import functools
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import fake_tk

PLATE_A, PLATE_EXP = "59D1-123.45", "51F-123.45"
_MODS = ("tkinter", "tkinter.ttk", "tkinter.messagebox", "tkinter.simpledialog", "tkinter.filedialog", "PIL.ImageTk",
         "app", "theme", "admin_web")


def gui(fn):
    """Mỗi test chạy xong thì trả lại sys.modules và camera như cũ, để không ảnh hưởng test khác."""
    @functools.wraps(fn)
    def wrapper(tmp_path):
        import camera
        saved, orig_open = {m: sys.modules.get(m) for m in _MODS}, camera.CameraStream.open
        try:
            return fn(tmp_path)
        finally:
            camera.CameraStream.open = orig_open
            for m, v in saved.items():
                if v is None:
                    sys.modules.pop(m, None)
                else:
                    sys.modules[m] = v
    return wrapper



class FakePipeline:
    """Máy nhận diện giả: trả lần lượt các kết quả test đặt trước."""
    def __init__(self):
        self.script = []

    def recognize(self, frame):
        from anpr import PlateResult
        return self.script.pop(0) if self.script else PlateResult(message="Không phát hiện được biển số trong ảnh")


def res(plate, conf=0.95):
    from anpr import PlateResult
    from plate_utils import normalize, pretty
    k = normalize(plate)
    return PlateResult(text=pretty(k), key=k, det_conf=0.9, ocr_conf=conf, box=(10, 10, 100, 50), valid=True)


def boot(tmp):
    dlg = fake_tk.install()
    for m in [m for m in sys.modules if m in ("app", "theme", "admin_web") ]:
        sys.modules.pop(m)
    import config
    config.ADMIN_WEB_ENABLED = False
    config.API_ENABLED = False
    config.BASE_DIR, config.IMAGE_DIR = Path(tmp), Path(tmp) / "img"      # ảnh test không ghi vào thư mục app
    import camera
    camera.CameraStream.open = lambda self, src: False                    # không mở camera thật khi test
    import app
    import db
    app.Database = lambda: db.Database(Path(tmp) / "g.db")
    pipe = FakePipeline()
    app.AnprPipeline = lambda: pipe
    root = app.App()
    root.pipeline = pipe
    return app, root, dlg, pipe


def login(root, app, user, pw):
    import tkinter.ttk as ttk
    e = fake_tk.find(root, ttk.Entry)
    e[0].opts["textvariable"].set(user)
    e[1].opts["textvariable"].set(pw)
    fake_tk.find(root, ttk.Button, text="ĐĂNG NHẬP")[0].opts["command"]()


def scan(guard, pipe, result, mode="scan"):
    pipe.script.append(result)
    guard.frame = np.zeros((480, 640, 3), np.uint8)
    guard.start(mode)
    for _ in range(300):
        guard._poll()
        if not guard.busy:
            break
        time.sleep(0.01)
    assert not guard.busy


def all_widgets(w):
    out = []
    for c in w.winfo_children():
        out.append(c)
        out += all_widgets(c)
    return out


@gui
def test_login_screen_and_guard_screen_build(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    login(root, app, "baove", "baove123")
    g = root.guard
    assert g.banner.opts["text"] == "SẴN SÀNG" and root.user["role"] == "GUARD"
    assert not [w for w in all_widgets(root) if isinstance(w, (app.SubscriptionTab, app.AuditTab))]   # bảo vệ không thấy tab Admin
    assert g.kpi["in"].opts["text"] == "0/9" and g.kpi["free"].opts["text"] == "9"
    g.set_status("Đã kết nối camera", "INFO")
    assert g.banner.opts["text"] == "SẴN SÀNG"                         # thông tin phụ không đè banner


@gui
def test_checkin_checkout_flow_updates_banner_plate_kpi_and_perf(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    login(root, app, "baove", "baove123")
    g = root.guard
    scan(g, pipe, res(PLATE_A))
    assert g.banner.opts["text"] == "MỜI VÀO" and g.banner.opts["bg"] == "#2e7d32"
    assert g.plate_lbl.opts["text"] == PLATE_A and g.kpi["in"].opts["text"] == "1/9"
    assert g.barrier.opts["text"] == "BARRIER: ĐANG MỞ"
    assert root.db.perf_summary("GATE")["n"] == 1                       # đã đo thời gian xử lý
    assert "Thời gian xử lý" in g.stat.opts["text"]
    scan(g, pipe, res(PLATE_A))
    assert g.banner.opts["text"] == "MỜI RA" and g.fee_lbl.opts["text"].startswith("Phí:")
    assert g.kpi["in"].opts["text"] == "0/9"
    assert g.listbox.size() >= 2


@gui
def test_low_confidence_asks_guard_and_logs_audit(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    login(root, app, "baove", "baove123")
    g = root.guard
    dlg.ask_string_result = [PLATE_A]                                   # bảo vệ sửa lại thành biển đúng
    scan(g, pipe, res("59D1-123.48", conf=0.6))
    assert any(c[0] == "askstring" for c in dlg.calls)
    assert g.plate_lbl.opts["text"] == PLATE_A
    ev = [e for e in root.db.audit_page(size=20) if e["event_type"] == "OCR_CORRECTED"]
    assert ev and ev[0]["username"] == "baove" and "59D1-123.48" in ev[0]["detail"] and PLATE_A in ev[0]["detail"]
    assert root.db.perf_summary("GATE") is None                         # có người can thiệp -> không tính chỉ tiêu 1.5 s


@gui
def test_unreadable_plate_beeps_and_manual_entry_is_audited(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    login(root, app, "baove", "baove123")
    dlg.ask_string_result = [PLATE_A]
    scan(g := root.guard, pipe, __import__("anpr").PlateResult(message="Không phát hiện được biển số"))
    assert g.banner.opts["text"] == "MỜI VÀO"
    assert any(e["event_type"] == "MANUAL_ENTRY" for e in root.db.audit_page(size=20))


@gui
def test_expired_subscription_warns(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    login(root, app, "baove", "baove123")
    from plate_utils import normalize, pretty
    k = normalize(PLATE_EXP)
    root.db.add_subscription(k, pretty(k), "An", "2026-01-01", "2026-02-01", 1)
    scan(root.guard, pipe, res(PLATE_EXP))
    assert root.guard.banner.opts["text"] == "CHÚ Ý"
    root.run_pending(2)
    assert any(c[0] == "showwarning" and "HẾT HẠN" in c[1][0] for c in dlg.calls)


@gui
def test_fix_dialog_correct_and_void(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    import tkinter.ttk as ttk                                          # sau boot(): lúc này tkinter giả mới có
    login(root, app, "baove", "baove123")
    g = root.guard
    scan(g, pipe, res("59D1-123.48"))
    g.fix_dialog()
    tree = fake_tk.find(g, ttk.Treeview)[-1]
    tree.selection_set(tree.get_children()[0])
    dlg.ask_string_result = [PLATE_A]
    fake_tk.find(g, ttk.Button, text="Sửa biển")[-1].opts["command"]()
    assert [l["plate_text"] for l in root.db.open_logs()] == [PLATE_A]
    tree = fake_tk.find(g, ttk.Treeview)[-1]
    tree.selection_set(tree.get_children()[0])
    dlg.yes = True
    fake_tk.find(g, ttk.Button, text="Hủy lượt vào (nhập nhầm)")[-1].opts["command"]()
    assert root.db.open_logs() == [] and g.kpi["in"].opts["text"] == "0/9"
    types = {e["event_type"] for e in root.db.audit_page(size=50)}
    assert {"PLATE_CORRECTED", "CHECKIN_VOIDED"} <= types


@gui
def test_lost_ticket_dialog_with_images_and_show_all(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    import tkinter.ttk as ttk                                          # sau boot(): lúc này tkinter giả mới có
    login(root, app, "baove", "baove123")
    g = root.guard
    for p in ("59D1-111.11", "30A-222.22", "51F-333.33", "29B1-444.44", "60A-555.55", "61A-666.66"):
        scan(g, pipe, res(p))
    frame = np.zeros((480, 640, 3), np.uint8)
    g.do_lost("59D1-111.12", "59D111112", frame)
    tree = fake_tk.find(g, ttk.Treeview)[-1]
    assert len(tree.get_children()) == 5                                # Top 5
    show_all = fake_tk.find(g, ttk.Checkbutton)[-3:]
    cb = [c for c in fake_tk.find(g, ttk.Checkbutton) if "TẤT CẢ" in c.opts["text"]][0]
    cb.opts["variable"].set(True)
    cb.opts["command"]()
    assert len(tree.get_children()) == 6                                # tất cả xe trong bãi
    tree.selection_set(tree.get_children()[0])
    dlg.yes = True
    fake_tk.find(g, ttk.Button, text="Chọn xe này & cho ra (phí mất thẻ)")[-1].opts["command"]()
    assert root.db.total_in_lot() == 5
    assert any(e["event_type"] == "LOST_TICKET" for e in root.db.audit_page(size=50))


@gui
def test_admin_tabs_build_and_work_then_logout(tmp_path):
    app, root, dlg, pipe = boot(tmp_path)
    login(root, app, "admin", "admin123")
    tabs = {type(w).__name__: w for w in all_widgets(root) if isinstance(w, (app.SubscriptionTab, app.HistoryTab,
                                                                              app.AuditTab, app.StatsTab))}
    assert set(tabs) == {"SubscriptionTab", "HistoryTab", "AuditTab", "StatsTab"}
    sub = tabs["SubscriptionTab"]
    for k, v in (("plate", PLATE_A), ("owner", "Nguyen Van A"), ("start", "2026-11-01"), ("end", "2026-12-01")):
        sub.vars[k].set(v)
    sub.add()
    assert len(root.db.list_subscriptions()) == 1
    sub.tree.selection_set(sub.tree.get_children()[0])
    dlg.yes = True
    sub.renew()
    assert len(root.db.list_subscriptions()) == 2
    sub.tree.selection_set(sub.tree.get_children()[0])
    sub.delete()
    tabs["AuditTab"].reload()
    tabs["AuditTab"].mode.set("Tất cả sự kiện")
    tabs["AuditTab"].reload()
    assert len(tabs["AuditTab"].tree.get_children()) >= 3
    tabs["HistoryTab"].q.set("59D1")
    tabs["HistoryTab"].reload()
    root.db.record_perf("GATE", 800, 1.5)
    tabs["StatsTab"].refresh()
    assert "Hiệu năng cổng" in tabs["StatsTab"].perf.opts["text"] and "1 lượt" in tabs["StatsTab"].perf.opts["text"]
    guard = root.guard
    root.logout()
    assert guard.destroyed and root.user is None
    root._tick_clock()                                                  # đồng hồ không lỗi khi đã đăng xuất
