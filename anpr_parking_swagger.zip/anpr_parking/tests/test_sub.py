"""Vé tháng: nhận biết còn hạn / sắp hết / hết hạn / chưa hiệu lực và cảnh báo lúc vào - ra."""
import random
import sys
from datetime import datetime
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import Database
from live import LiveState, draw_overlay
from plate_utils import normalize, pretty
from services import ParkingService


class Clock:
    def __init__(self):
        self.t = datetime(2026, 11, 22, 8, 0, 0)

    def __call__(self):
        return self.t


def make(tmp):
    clock = Clock()
    db = Database(Path(tmp) / "t.db")
    return ParkingService(db, clock=clock, rng=random.Random(1)), clock, db


def sub(db, plate, start, end):
    k = normalize(plate)
    db.add_subscription(k, pretty(k), "Nguyen Van A", start, end, 1)
    return k


def test_status_variants(tmp_path):
    svc, _, db = make(tmp_path)
    a = sub(db, "59D1-123.45", "2026-11-01", "2026-12-15")        # còn 23 ngày
    b = sub(db, "30A-123.45", "2026-11-01", "2026-11-25")         # còn 3 ngày -> sắp hết
    c = sub(db, "51F-123.45", "2026-10-01", "2026-11-10")         # đã hết hạn 12 ngày
    d = sub(db, "29B1-123.45", "2026-12-01", "2026-12-31")        # chưa bắt đầu
    assert svc.subscription_status(a).status == "ACTIVE" and not svc.subscription_status(a).soon
    assert svc.subscription_status(b).soon and svc.subscription_status(b).days == 3
    e = svc.subscription_status(c)
    assert e.status == "EXPIRED" and e.days == 12 and "HẾT HẠN" in e.label and "10/11/2026" in e.label
    assert svc.subscription_status(d).status == "NOT_STARTED"
    assert svc.subscription_status(normalize("60A-111.11")).status == "NONE"


def test_checkin_messages_and_events(tmp_path):
    svc, _, db = make(tmp_path)
    ok = sub(db, "59D1-123.45", "2026-11-01", "2026-12-15")
    old = sub(db, "51F-123.45", "2026-10-01", "2026-11-10")
    o1 = svc.check_in(pretty(ok), ok)
    assert o1.fee_type == "SUBSCRIPTION" and "VÉ THÁNG còn 23 ngày" in o1.message and o1.sub.status == "ACTIVE"
    o2 = svc.check_in(pretty(old), old)
    assert o2.sub.status == "EXPIRED" and "HẾT HẠN" in o2.message and "thu phí vé lẻ" in o2.message
    assert db._all("SELECT * FROM event_log WHERE event_type='SUB_EXPIRED'")
    o3 = svc.check_in("60A-111.11", normalize("60A-111.11"))
    assert o3.sub.status == "NONE" and "Vé lẻ" in o3.message


def test_checkout_free_vs_expired_fee(tmp_path):
    svc, clock, db = make(tmp_path)
    ok = sub(db, "59D1-123.45", "2026-11-01", "2026-12-15")
    old = sub(db, "51F-123.45", "2026-10-01", "2026-11-10")
    svc.check_in(pretty(ok), ok)
    svc.check_in(pretty(old), old)
    clock.t = clock.t.replace(hour=14)                              # đỗ 6 tiếng
    o1 = svc.process_scan(pretty(ok), ok)
    o2 = svc.process_scan(pretty(old), old)
    assert o1.fee == 0 and o1.fee_type == "SUBSCRIPTION"
    assert o2.fee > 0 and o2.fee_type == "EXPIRED_SUB" and "HẾT HẠN" in o2.message and o2.sub.status == "EXPIRED"


def test_renewal_makes_active_again(tmp_path):
    svc, _, db = make(tmp_path)
    old = sub(db, "51F-123.45", "2026-10-01", "2026-11-10")
    assert svc.subscription_status(old).status == "EXPIRED"
    db.add_subscription(old, pretty(old), "A", "2026-11-22", "2026-12-22", 1)       # gia hạn
    s = svc.subscription_status(old)
    assert s.status == "ACTIVE" and s.days == 30


def test_overlay_badge_drawn():
    img = np.zeros((300, 400, 3), np.uint8)
    st = LiveState((100, 100, 300, 160), "51F-123.45", 0.9, True, "51F12345", 0)
    plain = draw_overlay(img, st)
    with_badge = draw_overlay(img, st, ("VE THANG HET HAN 10/11/2026", (50, 50, 215)))
    assert (with_badge != plain).any() and (with_badge[170:200, 100:300] != 0).any()
