"""Test logic ghép ký tự của bộ YOLO (dùng model giả, không cần file .pt)."""
import numpy as np

from anpr_yolo import Det, YoloCharOCR, YoloPlateDetector


class FakeModel:
    def __init__(self, dets):
        self.dets = dets

    def predict(self, img, conf=0.25):
        return self.dets


def ch(label, cx, cy, conf=0.9, w=10, h=20):
    return Det(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, conf, label)


def test_one_line_sorted_left_to_right():
    dets = [ch(c, 20 + 15 * i, 30) for i, c in enumerate("51F12345")][::-1]    # đưa vào lộn xộn
    text, conf = YoloCharOCR(model=FakeModel(dets)).read(np.zeros((60, 200, 3), np.uint8))
    assert text == "51F12345" and conf > 0.8


def test_two_lines_top_then_bottom():
    top = [ch(c, 20 + 15 * i, 20) for i, c in enumerate("59D1")]
    bot = [ch(c, 20 + 15 * i, 60) for i, c in enumerate("12345")]
    text, _ = YoloCharOCR(model=FakeModel(bot + top)).read(np.zeros((90, 120, 3), np.uint8))
    assert text == "59D112345"


def test_duplicate_boxes_removed():
    dets = [ch("5", 20, 30, 0.9), ch("6", 21, 30, 0.5)] + [ch(c, 35 + 15 * i, 30) for i, c in enumerate("9D112345")]
    text, _ = YoloCharOCR(model=FakeModel(dets)).read(np.zeros((60, 200, 3), np.uint8))
    assert text == "59D112345"


def test_detector_picks_best_and_crops():
    img = np.zeros((200, 300, 3), np.uint8)
    d = YoloPlateDetector(model=FakeModel([Det(50, 60, 150, 100, 0.6, "p"), Det(10, 10, 90, 50, 0.9, "p")]))
    crop, box, conf = d.detect(img)
    assert conf == 0.9 and crop.shape[0] > 0 and box[0] <= 10 + 1


def test_detector_none_when_nothing():
    assert YoloPlateDetector(model=FakeModel([])).detect(np.zeros((100, 100, 3), np.uint8)) is None
