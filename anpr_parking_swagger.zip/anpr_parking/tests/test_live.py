"""Test nhận diện trực tiếp: bỏ phiếu nhiều khung hình + vẽ khung (dùng pipeline giả)."""
import time

import numpy as np

from anpr import PlateResult
from live import LiveRecognizer, draw_overlay


class FakePipeline:
    def __init__(self, seq):
        self.seq, self.i = seq, 0

    def recognize(self, frame):
        r = self.seq[min(self.i, len(self.seq) - 1)]
        self.i += 1
        return r


def res(key, valid=True, conf=0.9, box=(50, 60, 250, 140)):
    return PlateResult(text=key, key=key, det_conf=0.9, ocr_conf=conf, box=box, valid=valid)


def run(seq, min_votes=2):
    lr = LiveRecognizer(lambda: FakePipeline(seq), history=6)
    lr.min_votes = min_votes
    for r in seq:                      # gọi _update trực tiếp để test xác định, không phụ thuộc thời gian luồng
        lr._update(r)
    lr.stop()
    return lr


def test_majority_vote_fixes_single_misread():
    lr = run([res("59D112345"), res("59D112845", valid=True, conf=0.5), res("59D112345"), res("59D112345")])
    s = lr.snapshot()
    assert s.key == "59D112345" and s.stable and s.text == "59D1-123.45"


def test_not_stable_until_two_agree():
    lr = run([res("59D112345")])
    assert lr.snapshot().stable is False and lr.stable_key() is None
    lr2 = run([res("59D112345")], min_votes=1)
    assert lr2.stable_key() == "59D112345"


def test_unsure_text_shown_orange_not_stable():
    lr = run([res("59D1X23", valid=False, conf=0.3)])
    s = lr.snapshot()
    assert s.text == "59D1X23" and not s.stable and s.key == ""


def test_no_plate_clears_overlay():
    lr = run([res("59D112345"), PlateResult(message="no")])
    lr.state.ts -= 5
    lr._update(PlateResult(message="no"))
    assert lr.snapshot() is None


def test_thread_processes_latest_frame():
    lr = LiveRecognizer(lambda: FakePipeline([res("30A12345")]))
    lr.min_votes = 1
    lr.submit(np.zeros((100, 100, 3), np.uint8))
    for _ in range(50):
        if lr.snapshot():
            break
        time.sleep(0.05)
    lr.stop()
    assert lr.snapshot() and lr.snapshot().key == "30A12345"


def test_draw_overlay_changes_pixels_and_keeps_source():
    img = np.zeros((300, 400, 3), np.uint8)
    lr = run([res("59D112345"), res("59D112345")])
    out = draw_overlay(img, lr.snapshot())
    assert out.sum() > 0 and img.sum() == 0 and out.shape == img.shape
    assert (draw_overlay(img, None) == img).all()
