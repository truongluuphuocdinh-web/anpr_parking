"""REST API + Swagger UI (api_server.py): đăng nhập, phân quyền, luồng cổng, vé tháng, Audit Log, openapi.json."""
import json
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import api_server
import export_openapi


@pytest.fixture()
def client(tmp_path):
    app = api_server.create_app(tmp_path / "t.db")
    with TestClient(app) as c:
        yield c


def login(c, user="admin", pw="admin123"):
    r = c.post("/api/auth/login", json={"username": user, "password": pw})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["access_token"]}


def test_swagger_ui_and_openapi_json(client, tmp_path):
    assert client.get("/docs").status_code == 200 and "swagger-ui" in client.get("/docs").text
    assert client.get("/static/swagger/swagger-ui-bundle.js").status_code == 200      # chạy offline được
    spec = client.get("/openapi.json").json()
    assert spec["openapi"].startswith("3.") and spec["info"]["title"]
    assert "/api/gate/scan" in spec["paths"] and "OAuth2PasswordBearer" in spec["components"]["securitySchemes"]
    out = export_openapi.export(tmp_path / "openapi.json")
    assert json.loads(out.read_text(encoding="utf-8"))["paths"].keys() == spec["paths"].keys()


def test_auth_required_and_roles(client):
    assert client.get("/api/lot").status_code == 401
    assert client.post("/api/auth/login", json={"username": "admin", "password": "sai"}).status_code == 401
    g = login(client, "baove", "baove123")
    assert client.get("/api/lot", headers=g).status_code == 200
    for url in ("/api/subscriptions", "/api/audit", "/api/stats/daily"):
        assert client.get(url, headers=g).status_code == 403
    a = login(client)
    assert client.get("/api/subscriptions", headers=a).status_code == 200
    me = client.get("/api/auth/me", headers=a).json()
    assert me["role"] == "ADMIN" and me["using_default_password"] is True
    client.post("/api/auth/logout", headers=a)
    assert client.get("/api/lot", headers=a).status_code == 401


def test_swagger_authorize_form_login(client):
    r = client.post("/api/auth/token", data={"username": "baove", "password": "baove123"})
    assert r.status_code == 200 and r.json()["role"] == "GUARD"


def test_lockout_after_5_failures(client):
    for _ in range(5):
        assert client.post("/api/auth/login", json={"username": "admin", "password": "x"}).status_code == 401
    assert client.post("/api/auth/login", json={"username": "admin", "password": "admin123"}).status_code == 429


def test_gate_flow_checkin_near_checkout_lost_move_void(client):
    h = login(client, "baove", "baove123")
    r = client.post("/api/gate/scan", json={"plate": "59d1-123.45"}, headers=h).json()
    assert r["action"] == "CHECK_IN" and r["plate"] == "59D1-123.45" and r["slot"]
    lot = client.get("/api/lot", headers=h).json()
    assert lot["occupied"] == 1 and lot["free"] == 8 and lot["total"] == 9
    near = client.post("/api/gate/scan", json={"plate": "59O1-123.45"}, headers=h).json()
    assert near["action"] == "WARN_NEAR" and near["near_plate"] == "59D1-123.45"
    out = client.post("/api/gate/confirm-near", json={"log_id": near["near_log_id"], "read_text": "59O1-123.45"},
                      headers=h).json()
    assert out["action"] == "CHECK_OUT" and out["fee"] == 0
    assert client.post("/api/gate/confirm-near", json={"log_id": near["near_log_id"]}, headers=h).status_code == 409
    assert client.post("/api/gate/scan", json={"plate": "abc"}, headers=h).status_code == 422

    a = client.post("/api/gate/scan", json={"plate": "30A-123.45"}, headers=h).json()
    cands = client.get("/api/gate/lost-ticket/candidates", params={"plate": "30A-123.46"}, headers=h).json()
    assert cands[0]["log_id"] == a["log_id"] and cands[0]["distance"] == 1
    lost = client.post("/api/gate/lost-ticket", json={"log_id": a["log_id"]}, headers=h).json()
    assert lost["fee_type"] == "LOST_TICKET" and lost["fee"] == 50000

    b = client.post("/api/gate/scan", json={"plate": "51F-123.45"}, headers=h).json()
    free = next(s["code"] for s in client.get("/api/lot", headers=h).json()["slots"] if not s["occupied"])
    assert client.post("/api/lot/move", json={"from_slot": b["slot"], "to_slot": free}, headers=h).status_code == 200
    assert client.post("/api/lot/move", json={"from_slot": b["slot"], "to_slot": free}, headers=h).status_code == 409
    assert client.patch(f"/api/logs/{b['log_id']}/plate", json={"plate": "51F-123.46"}, headers=h).status_code == 200
    assert client.delete(f"/api/logs/{b['log_id']}", headers=h).status_code == 200
    assert client.get("/api/lot", headers=h).json()["occupied"] == 0

    page = client.get("/api/history", params={"size": 1}, headers=h).json()          # còn 2 lượt: 30A (mới), 59D1 (cũ)
    assert [i["plate_text"] for i in page["items"]] == ["30A-123.45"] and page["next_before"]
    old = client.get("/api/history", params={"before": page["next_before"], "q": "59D1"}, headers=h).json()
    assert [i["plate_text"] for i in old["items"]] == ["59D1-123.45"]


def test_subscriptions_stats_audit_export(client):
    a = login(client)
    body = {"plate": "59D1-123.45", "owner": "An", "start_date": "2026-11-01", "end_date": "2026-12-01"}
    r = client.post("/api/subscriptions", json=body, headers=a)
    assert r.status_code == 201 and r.json()["plate"] == "59D1-123.45"
    assert client.post("/api/subscriptions", json=body, headers=a).status_code == 409          # trùng kỳ
    assert client.post("/api/subscriptions", json={**body, "plate": "xx"}, headers=a).status_code == 422
    assert client.post("/api/subscriptions", json={**body, "plate": "30A-123.45", "end_date": "2026-10-01"},
                       headers=a).status_code == 400
    sid = r.json()["id"]
    assert client.post(f"/api/subscriptions/{sid}/renew", headers=a).status_code == 200
    assert len(client.get("/api/subscriptions", headers=a).json()) == 2
    assert client.delete(f"/api/subscriptions/{sid}", headers=a).status_code == 200
    assert client.delete(f"/api/subscriptions/{sid}", headers=a).status_code == 404

    h = login(client, "baove", "baove123")
    client.post("/api/gate/scan", json={"plate": "29A-111.22"}, headers=h)
    client.post("/api/gate/scan", json={"plate": "29A-111.22"}, headers=h)
    st = client.get("/api/stats/daily", headers=a).json()
    assert st and st[-1]["vao"] == 1 and st[-1]["ra"] == 1
    assert client.get("/api/stats/performance", headers=a).json()["n"] >= 2

    ev = client.get("/api/audit", params={"all_events": True}, headers=a).json()["items"]
    assert {"SUB_ADDED", "SUB_RENEWED", "SUB_DELETED", "LOGIN"} <= {e["event_type"] for e in ev}
    x = client.get("/api/export/revenue", params={"from": "2026-11-01", "to": "2026-11-30"}, headers=a)
    assert x.status_code == 200 and x.content[:2] == b"PK"
    assert client.get("/api/export/audit", headers=a).content[:2] == b"PK"
    assert client.get("/api/export/revenue", params={"from": "2026-12-01", "to": "2026-11-01"},
                      headers=a).status_code == 400


def test_password_change_and_recognize_unavailable(client):
    a = login(client)
    assert client.post("/api/auth/password", json={"old_password": "sai", "new_password": "matkhau1"},
                       headers=a).status_code == 400
    assert client.post("/api/auth/password", json={"old_password": "admin123", "new_password": "matkhau1"},
                       headers=a).status_code == 200
    login(client, "admin", "matkhau1")
    assert client.post("/api/gate/recognize", files={"file": ("a.png", b"x", "image/png")},
                       headers=a).status_code == 503                      # chưa nạp pipeline
