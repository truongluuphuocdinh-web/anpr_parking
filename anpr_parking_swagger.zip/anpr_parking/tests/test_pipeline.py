import sys
from pathlib import Path

import cv2

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from anpr import AnprPipeline, PlateOCR
from make_demo_plates import make


class StubOCR(PlateOCR):
    """OCR giả để test pipeline mà không cần cài easyocr."""
    def __init__(self, text, conf=0.9):
        self.text, self.conf = text, conf

    def read(self, crop):
        assert crop.size > 0
        return self.text, self.conf


def run(tmp_path, plate, ocr_text, conf=0.9):
    p = tmp_path / "p.png"
    make(plate, p)
    pl = AnprPipeline.__new__(AnprPipeline)
    from anpr import PlateDetector
    pl.detector, pl.ocr = PlateDetector(model_path=tmp_path / "none.pt"), StubOCR(ocr_text, conf)
    return pl.recognize(cv2.imread(str(p)))


def test_pipeline_ok(tmp_path):
    r = run(tmp_path, "59D1-123.45", "59D1 123.45")
    assert r.valid and r.key == "59D112345" and r.text == "59D1-123.45"


def test_pipeline_low_confidence_needs_manual(tmp_path):
    r = run(tmp_path, "59D1-123.45", "59D1 123.45", conf=0.1)
    assert not r.valid and r.message


def test_pipeline_garbage_needs_manual(tmp_path):
    r = run(tmp_path, "51F-123.45", "@@##")
    assert not r.valid


def test_no_plate_in_blank_image(tmp_path):
    import numpy as np
    pl = AnprPipeline.__new__(AnprPipeline)
    from anpr import PlateDetector
    pl.detector, pl.ocr = PlateDetector(model_path=tmp_path / "none.pt"), StubOCR("x")
    r = pl.recognize(np.full((480, 640, 3), 120, np.uint8))
    assert not r.valid and "Không phát hiện" in r.message
