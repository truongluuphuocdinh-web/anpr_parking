import sys
from pathlib import Path

import cv2
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from anpr import AnprPipeline, PlateDetector, PlateOCR
from make_demo_plates import make
from plate_utils import is_valid, normalize


def test_split_lines():
    assert len(PlateOCR.split_lines(np.zeros((150, 200), np.uint8))) == 2     # biển xe máy (2 dòng)
    assert len(PlateOCR.split_lines(np.zeros((100, 400), np.uint8))) == 1     # biển ô tô (1 dòng)


def test_prefers_valid_combination():
    """Dòng 1 có một biến thể đọc sai nhưng tự tin hơn (5ID1), dòng 2 đọc nhiễu: phải chọn tổ hợp đúng định dạng."""
    ocr = PlateOCR.__new__(PlateOCR)
    ocr.engine, ocr.backend, ocr.error, ocr.last_debug = object(), "stub", "", []
    outputs = iter([("59D1", .9), ("59D1", .9), ("5ID1", .95), ("59D1", .9),          # dòng 1
                    ("123.45", .9), ("12345", .9), ("123.4S", .97), ("123.45", .9)])  # dòng 2
    ocr._rec = lambda img: next(outputs)
    crop = np.full((150, 200, 3), 255, np.uint8)
    cv2.putText(crop, "X", (80, 90), cv2.FONT_HERSHEY_DUPLEX, 2, (0, 0, 0), 4)
    text, conf = ocr.read(crop)
    assert is_valid(normalize(text)) and normalize(text) == "59D112345"


def test_no_engine_raises():
    ocr = PlateOCR.__new__(PlateOCR)
    ocr.engine, ocr.error = None, "chưa cài"
    with pytest.raises(RuntimeError):
        ocr.read(np.zeros((50, 100, 3), np.uint8))


rapid = pytest.importorskip("rapidocr_onnxruntime")


@pytest.mark.parametrize("plate", ["59D1-123.45", "51F-123.45", "29MD-123.45", "30A-678.90"])
@pytest.mark.parametrize("angle", [0, -6, 6])
def test_real_ocr_end_to_end(tmp_path, plate, angle):
    p = tmp_path / "p.png"
    make(plate, p)
    img = cv2.imread(str(p))
    if angle:
        M = cv2.getRotationMatrix2D((320, 240), angle, 1)
        img = cv2.warpAffine(img, M, (640, 480), borderValue=(90, 90, 90))
    pl = AnprPipeline.__new__(AnprPipeline)
    pl.detector, pl.ocr = PlateDetector(model_path=tmp_path / "none.pt"), PlateOCR(backend="rapidocr")
    r = pl.recognize(img)
    assert r.valid and r.text == plate
