"""Test nguồn camera: chuẩn hoá URL, mở file/luồng MJPEG qua HTTP giả lập điện thoại, nguồn hỏng."""
import http.server
import threading
import time

import cv2
import numpy as np

from camera import CameraStream, normalize_url


def test_normalize_url():
    assert normalize_url("192.168.1.5:8080") == "http://192.168.1.5:8080/video"
    assert normalize_url("http://192.168.1.5:4747/") == "http://192.168.1.5:4747/video"
    assert normalize_url("http://10.0.0.2:8080/video") == "http://10.0.0.2:8080/video"
    assert normalize_url("rtsp://10.0.0.2:8554/live") == "rtsp://10.0.0.2:8554/live"
    assert normalize_url("  ") == ""


def test_bad_source_returns_false_quickly():
    cam = CameraStream()
    t = time.time()
    assert cam.open("http://127.0.0.1:1/video") is False and cam.error
    assert time.time() - t < 10 and not cam.isOpened()


class _MJPEG(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
        self.end_headers()
        try:
            for i in range(400):
                img = np.full((720, 1920, 3), i % 255, np.uint8)       # khung 1920 rộng -> phải được thu nhỏ
                ok, jpg = cv2.imencode(".jpg", img)
                self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n" % len(jpg))
                self.wfile.write(jpg.tobytes() + b"\r\n")
                time.sleep(0.03)
        except Exception:
            pass


def test_mjpeg_phone_stream():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _MJPEG)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    cam = CameraStream(max_width=1280)
    try:
        assert cam.open(f"http://127.0.0.1:{srv.server_port}/video")
        got = None
        for _ in range(60):
            ok, f = cam.read()
            if ok:
                got = f
                break
            time.sleep(0.05)
        assert got is not None and got.shape[1] == 1280              # đã thu nhỏ từ 1920
        assert cam.stale(3.0) is False
        assert cam.read()[0] in (True, False)
    finally:
        cam.release()
        srv.shutdown()


def test_switch_source_releases_old():
    cam = CameraStream()
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _MJPEG)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        assert cam.open(f"http://127.0.0.1:{srv.server_port}/video")
        cam.release()
        assert not cam.isOpened() and cam.read() == (False, None)
    finally:
        srv.shutdown()
